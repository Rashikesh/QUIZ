package com.demo.registration;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	
	private static final String INSERT_QUERY="INSERT INTO registeration(UserName,email,pass)values(?,?,?);";
	
	private static final long serialVersionUID = 1L;

	//private static final String PreparedStatement  = null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		// fetching data from html file 
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		
		System.out.println("Name "+ name);
		System.out.println("email "+ email);
		System.out.println("password "+ pass);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","harsh@7294");
				PreparedStatement ps =con.prepareStatement(INSERT_QUERY);){
			 ps.setString(1,name );
			 ps.setString(2,email );
			 ps.setString(3,pass );
			 //using this data to store in database
			 int count= ps.executeUpdate();
			 if (count==0) {
				pw.println("not saved");
			}
			 else 
			 {
				 pw.println("updated successed ");
				 pw.println("<br><a href=login.jsp>login now</a>");
			 }
			 
		} catch (Exception e) {
			// TODO: handle exception
			pw.println(e.getMessage());
		}
		
		pw.close();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doGet(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
