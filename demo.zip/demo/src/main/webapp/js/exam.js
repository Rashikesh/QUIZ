const quizDb=[
    {
        question:"Q1: What is the full form of HTML?",
        a:"Hyper Text Maker Language",
        b:"Hyp Title Makup Language",
        c:"Hvk Text Maker Language",
        d:"HyperText Makup Language",
        ans:"ans4"
    },{
        question:"Q2: What is Port of mysql?",
        a:"676",
        b:"330",
        c:"3062",
        d:"3306",
        ans:"ans4"
    },
    {
        question:"Q3: Whta is Pure Object Oriented Language ?",
        a:"HTML",
        b:"JSP",
        c:"Java",
        d:"C++",
        ans:"ans3"
    }
];
const question = document.querySelector('.question');
const option1 = document.querySelector('#option1');
const option2 = document.querySelector('#option2');
const option3 = document.querySelector('#option3');
const option4 = document.querySelector('#option4');
const submit = document.querySelector('#submit');

const answers = document.querySelectorAll('.answer');

const showScore = document.querySelector('#showScore');

let questionCount = 0;
let score = 0;
const loadQuestion = () => {
    // console.log(quizDb[0].question);
    const questionList = quizDb[questionCount];

    question.innerText = questionList.question;

    option1.innerText = questionList.a;
    option2.innerText = questionList.b;
    option3.innerText = questionList.c;
    option4.innerText = questionList.d;
}

loadQuestion();

const getCheckAnswer = () => {
    let answer;
    answers.forEach((curAnsElem) =>{
        if (curAnsElem.checked ) {
            answer = curAnsElem.id;
        }
    });
    return answer;
};

submit.addEventListener('click', ()=> {
    const checkedAnswer = getCheckAnswer();
    console.log(checkedAnswer);
    if (checkedAnswer === quizDb[questionCount].ans) {
        score++;
    };

    questionCount++;
    if(questionCount < quizDb.length){
        loadQuestion();
    }else{
        showScore.innerHTML = `
        <h3> You Scored ${score}/${quizDb.length} 😇</h3>
        <button class="btn"  onClick="location.relaod()">Play Again</button>
        `;
        showScore.classList.remove('scoreArea');

    }

});